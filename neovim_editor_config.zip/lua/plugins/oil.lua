return {
	"stevearc/oil.nvim",
	---@module 'oil'
	---@type oil.SetupOpts
	config = function()
		require("oil").setup({})
	end,
}
