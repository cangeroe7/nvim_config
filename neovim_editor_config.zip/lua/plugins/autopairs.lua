return {
	"windwp/nvim-autopairs",
	event = "InsertEnter",
	config = true,
}
