return {
  "echasnovski/mini.surround",
  config = function()
    require("mini.surround").setup()
  end,
}
